# File generated from our OpenAPI spec by Stainless.


__all__ = ["FileContent"]

FileContent = str
